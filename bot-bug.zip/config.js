module.exports = {
  BOT_TOKEN: '7943155396:AAEWD9J4tTjR7blOjCiZpgFGtQRwuzc9vsI', 
  OWNER_ID: ['7615833617']
};
